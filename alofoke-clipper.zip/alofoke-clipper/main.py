"""Bot clipper 24/7 de La Casa de Alofoke 3.

Cada turno de GitHub Actions graba el directo SIN PARAR durante 4 horas, en pedazos de 1 hora.
Mientras graba, procesa cada pedazo terminado:
  transcribe -> la IA elige los momentos -> edita Reels 9:16 -> cola -> publica el mejor cuando toca.
Al final del turno, los pedazos que no alcanzó a procesar se le entregan al siguiente turno,
que ya está en fila. Así no hay huecos en la grabación."""
import glob
import hashlib
import uuid
import json
import os
import shutil
import subprocess
import time
import traceback
from datetime import datetime

from clipper import analisis, captura, cola, config, editar, elegir, publicar, reparto, aprendizaje

TRABAJO = "trabajo"
SEG_DIR = os.path.join(TRABAJO, "segmentos")
COLA_DIR = os.path.join(TRABAJO, "cola")
SOLAPE_SEG = 90  # se repiten los últimos 90 s de la hora anterior para no partir momentos


def ahora():
    return datetime.now(config.ZONA)


def descripcion(clip):
    return f"{clip['titulo']}\n\n{clip['descripcion']}\n\n{config.HASHTAGS}".strip()


def _ffmpeg(*args):
    subprocess.run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", *args], check=True)


class Bot:
    def __init__(self):
        cola.preparar()
        self.estado, self.cola = cola.descargar(COLA_DIR)
        self.estado.pop("publicaciones", None)  # formato viejo (una sola página)
        self.producidos = 0
        self.sin_clips_seguidos = 0
        self.segundos_sin_clips = 0.0
        self.cola_previa = None  # últimos segundos del pedazo anterior

    # ---------- producción ----------
    def _unir_con_previa(self, video):
        """Pega los últimos 90 s del pedazo anterior al inicio de este."""
        if not (self.cola_previa and os.path.exists(self.cola_previa)):
            return video, 0.0
        unido = os.path.join(TRABAJO, "unido_" + os.path.basename(video))  # fuera de SEG_DIR
        try:
            _ffmpeg("-i", f"concat:{self.cola_previa}|{video}", "-c", "copy",
                    "-fflags", "+genpts", unido)
            return unido, editar.duracion(self.cola_previa)
        except subprocess.CalledProcessError:
            return video, 0.0

    def _guardar_cola_previa(self, video):
        previa = os.path.join(TRABAJO, "previa.ts")
        try:
            _ffmpeg("-sseof", f"-{SOLAPE_SEG}", "-i", video, "-c", "copy", previa)
            self.cola_previa = previa
        except subprocess.CalledProcessError:
            self.cola_previa = None

    def _registrar_segmento(self, segundos, nuevos):
        if nuevos:
            self.sin_clips_seguidos = 0
            self.segundos_sin_clips = 0.0
            return
        self.sin_clips_seguidos += 1
        self.segundos_sin_clips += segundos
        print(f"[main] sin clips aptos: {self.sin_clips_seguidos} fragmentos, "
              f"{self.segundos_sin_clips / 60:.1f} min de contenido analizado")
        if self.sin_clips_seguidos >= 3:
            publicar.telegram(
                f"Bot Alofoke: {self.sin_clips_seguidos} fragmentos consecutivos "
                f"({self.segundos_sin_clips / 60:.1f} minutos de contenido analizado) "
                f"sin clips aptos de {config.PUNTAJE_MINIMO}/10 o mas. "
                "Revisa los motivos de descarte en Actions.",
                clave="sin_clips", cada_min=30)

    def procesar_segmento(self, original):
        dur_original = editar.duracion(original)
        if dur_original < 60:
            print("[main] fragmento demasiado corto; no analizado")
            return
        if config.FUENTE == "drive":  # cada grabación es independiente: sin solape
            video, solape = original, 0.0
        else:
            video, solape = self._unir_con_previa(original)
            self._guardar_cola_previa(original)
        dur = editar.duracion(video)
        wav = video.replace(".ts", ".wav")
        wav_voz = video.replace(".ts", "_voz.wav")
        try:
            captura.extraer_audio(video, wav, wav_voz)
            segmentos = analisis.transcribir(wav_voz)
            if not segmentos and not config.MEMES_SELECTIVOS:
                print("[main] sin conversaciones transcritas")
                self._registrar_segmento(dur_original, 0)
                return
            z = analisis.energia_por_segundo(wav)
            elegidos = elegir.elegir(segmentos, z, analisis.picos(z), dur, video=video)
            # Un clip que termina dentro del solape ya lo vio la hora anterior.
            antes = len(elegidos)
            elegidos = [c for c in elegidos if c["fin"] > solape + 5]
            print(f"[main] descartados por solape previo: {antes-len(elegidos)}")
            ancho, alto = editar.tamano_video(video)
            sello = int(time.time())
            nuevos = 0
            for i, clip in enumerate(elegidos):
                if not clip.get("revision_manual") and clip["puntaje"] < config.PUNTAJE_MINIMO:
                    print(f"[main] descartado por puntaje: {clip['puntaje']}")
                    continue
                nombre = f"clip-{sello}-{uuid.uuid4().hex[:10]}"
                clip.update({"nombre": nombre, "huella": reparto.huella(" ".join(
                    w["texto"] for seg in segmentos for w in seg.get("palabras", [])
                    if clip["inicio"] <= w["inicio"] < clip["fin"]))})
                if not clip.get("revision_manual") and any(reparto.duplicado(clip, c)
                        for c in self.cola + self.estado.get("historial_clips", [])):
                    print("[main] descartado por duplicado en cola o historial")
                    continue
                salida = os.path.join(TRABAJO, nombre + ".mp4")
                try:
                    editar.editar(video, clip, segmentos, salida, ancho, alto)
                    clip["duracion_real"] = editar.duracion(salida)
                    clip["formato"] = "vertical" if editar.tamano_video(salida) == (1080, 1920) else "cuadrado"
                    if clip["duracion_real"] < config.CLIP_MIN_SEG * 0.7:
                        raise RuntimeError("el clip salió demasiado corto")
                except Exception as e:
                    print(f"[main] no se pudo editar {nombre}: {e}")
                    continue
                if clip.get("revision_manual"):
                    if config.ENVIAR_TODOS_TELEGRAM or config.MODO_PRUEBA:
                        publicar.telegram("[REVISIÓN MANUAL] " + descripcion(clip), salida)
                    os.remove(salida)
                    continue
                with open(salida, "rb") as f:
                    clip["sha256"] = hashlib.file_digest(f, "sha256").hexdigest()
                clip.update({"nombre": nombre, "creado": sello})
                meta = os.path.join(TRABAJO, nombre + ".json")
                with open(meta, "w") as f:
                    json.dump(clip, f, ensure_ascii=False)
                try:
                    cola.subir(salida, meta)
                except RuntimeError as e:
                    print("[main] no se pudo guardar en la cola (queda solo en este turno):", e)
                clip["ruta"] = salida
                self.cola.append(clip)
                self.producidos += 1
                nuevos += 1
                if config.ENVIAR_TODOS_TELEGRAM:
                    publicar.telegram(f"[{clip['puntaje']}/10] {descripcion(clip)}", salida)
            self._registrar_segmento(dur_original, nuevos)
            self.podar_cola()
        finally:
            for f in (wav, wav_voz, video if video != original else None):
                if f and os.path.exists(f):
                    os.remove(f)

    def podar_cola(self):
        """Bota lo viejo y deja solo los MAX_COLA mejores."""
        limite = time.time() - config.MAX_EDAD_HORAS * 3600
        historial = self.estado.get("historial_clips", [])
        vivos = [c for c in self.cola if c["creado"] >= limite
                 and c["puntaje"] >= config.PUNTAJE_MINIMO and not c.get("revision_manual")
                 and not any(reparto.duplicado(c, h) for h in historial)]
        vivos.sort(key=lambda c: (-c["puntaje"], -c["creado"]))
        quedan, sobran = vivos[: config.MAX_COLA], vivos[config.MAX_COLA:]
        sobran += [c for c in self.cola if c not in vivos]
        for c in sobran:
            cola.borrar(c["nombre"] + ".mp4", c["nombre"] + ".json")
            if c.get("ruta") and os.path.exists(c["ruta"]):
                os.remove(c["ruta"])
        self.cola = quedan

    # ---------- publicación ----------
    def _pagina(self, pid):
        return self.estado.setdefault("paginas", {}).setdefault(pid, {"publicaciones": []})

    def puede_publicar(self, pagina):
        """Máximo de 17 en 24 h y un clip por ventana local."""
        t = time.time()
        p = self._pagina(pagina["id"])
        p["publicaciones"] = [x for x in p["publicaciones"] if t - x < 86400]
        if t < p.get("reintentar_desde", 0):
            return False
        indice = next((i for i, pg in enumerate(config.FB_PAGINAS) if pg["id"] == pagina["id"]), -1)
        slot = reparto.turno(ahora(), indice, len(config.FB_PAGINAS))
        if not slot or p.get("ultimo_turno") == slot:
            return False
        if len(p["publicaciones"]) >= config.MAX_POR_DIA:
            return False
        return t - max(p["publicaciones"], default=0) >= config.MIN_ENTRE_POSTS * 60

    def total_24h(self):
        return sum(len(self._pagina(pg["id"])["publicaciones"]) for pg in config.FB_PAGINAS)

    def _guardar_estado(self):
        try:
            cola.guardar_estado(self.estado, COLA_DIR)
        except Exception as e:
            print("[main] no se pudo guardar el estado (se reintenta luego):", e)

    def intentar_publicar(self):
        # Recorre las páginas: a cada una le toca el mejor clip que quede (nunca el mismo).
        for pagina in config.FB_PAGINAS:
            if not self.cola or not self.puede_publicar(pagina):
                continue
            self.podar_cola()
            if not self.cola:
                return
            ajustes, _ = aprendizaje.perfil(self.estado, pagina["id"])
            self.cola.sort(key=lambda c: (-aprendizaje.prioridad(c, ajustes), -c["creado"]))
            clip = self.cola[0]
            ruta = clip.get("ruta") if clip.get("ruta") and os.path.exists(clip["ruta"]) else \
                cola.bajar_video(clip["nombre"] + ".mp4", COLA_DIR)
            if not ruta:
                self.cola.pop(0)
                continue
            try:
                if editar.tamano_video(ruta) not in ((1080, 1080), (1080, 1920)) or editar.duracion(ruta) < config.CLIP_MIN_SEG * 0.7 or editar._congelamiento_inicial(ruta):
                    raise RuntimeError("inicio congelado o clip corto en cola")
            except Exception as e:
                print(f"[main] descarto clip de cola no validado: {clip['nombre']}: {e}")
                self.cola.pop(0)
                cola.borrar(clip["nombre"] + ".mp4", clip["nombre"] + ".json")
                if os.path.exists(ruta):
                    os.remove(ruta)
                continue
            datos = self._pagina(pagina["id"])
            nombre = pagina["nombre"]
            try:
                if config.MODO_PRUEBA:
                    print("[main] prueba: no se publica ni consume el turno")
                    return
                # Reserva persistente antes de enviar: ante un resultado ambiguo no duplicar.
                indice = next(i for i, pg in enumerate(config.FB_PAGINAS) if pg["id"] == pagina["id"])
                slot = reparto.turno(ahora(), indice, len(config.FB_PAGINAS))
                if not slot or not self.puede_publicar(pagina):
                    continue
                historial = self.estado.setdefault("historial_clips", [])
                reserva = {k: clip[k] for k in ("nombre", "huella", "sha256") if k in clip}
                reserva.update({"pagina": pagina["id"], "fecha": time.time()})
                aprendizaje.registrar(self.estado, reserva, clip)
                historial.append(reserva)
                datos["ultimo_turno"] = slot
                datos["publicaciones"].append(time.time())
                try:
                    cola.guardar_estado(self.estado, COLA_DIR)
                except Exception:
                    historial.pop()
                    datos["publicaciones"].pop()
                    datos.pop("ultimo_turno", None)
                    print("[main] sin persistencia de reserva; no publico")
                    return
                import tempfile
                with tempfile.TemporaryDirectory() as tmp_marca:
                    marcado = os.path.join(tmp_marca, "reel.mp4")
                    editar.marcar_pagina(ruta, marcado, nombre)
                    vid = publicar.reel(marcado, descripcion(clip), pagina["id"], pagina["token"])
                reserva["video_id"] = vid
                self._guardar_estado()
                estado_fb = publicar.estado_reel(vid, pagina["token"])
                reserva["estado_fb"] = estado_fb
            except publicar.ErrorFacebook as e:
                print(f"[main] error al publicar en {nombre}:", e)
                if e.token_malo:
                    datos["reintentar_desde"] = time.time() + 6 * 3600
                    publicar.telegram(f"Bot Alofoke: el token de {nombre} venció o perdió permisos. "
                                      f"Pausé esa página 6 horas. Saca un token nuevo y cámbialo en "
                                      f"el secreto FB_PAGINAS. Detalle: {e.mensaje}",
                                      clave=f"token_{pagina['id']}", cada_min=360)
                elif e.limite:
                    datos["reintentar_desde"] = time.time() + 2 * 3600
                    publicar.telegram(f"Bot Alofoke: Facebook frenó a {nombre} por límite. "
                                      f"Pauso 2 horas. Detalle: {e.mensaje}",
                                      clave=f"limite_{pagina['id']}", cada_min=120)
                else:
                    datos["reintentar_desde"] = time.time() + 15 * 60
                    publicar.telegram(f"Bot Alofoke: error al publicar en {nombre}: {e}",
                                      clave=f"error_{pagina['id']}", cada_min=60)
                self._guardar_estado()
                continue
            except Exception as e:  # red caída, etc.
                print(f"[main] fallo de red publicando en {nombre}:", e)
                datos["reintentar_desde"] = time.time() + 10 * 60
                self._guardar_estado()
                continue

            self.cola.pop(0)
            cola.borrar(clip["nombre"] + ".mp4", clip["nombre"] + ".json")
            self._guardar_estado()
            n = len(datos["publicaciones"])
            if estado_fb == "error":
                publicar.telegram(f"Bot Alofoke: Facebook rechazó el Reel '{clip['titulo']}' en {nombre} "
                                  f"al procesarlo (video {vid}). Sigo con el siguiente.",
                                  clave=f"rechazo_{pagina['id']}", cada_min=30)
            aviso = (f"Facebook ({estado_fb}) en {nombre} ({n}/{config.MAX_POR_DIA} en 24 h, "
                     f"puntaje {clip['puntaje']}): {clip['titulo']} [{vid}]")
            print("[main]", aviso)
            publicar.telegram(aviso, None if config.ENVIAR_TODOS_TELEGRAM else ruta)
            if os.path.exists(ruta):
                os.remove(ruta)

    # ---------- ciclo ----------
    def correr(self):
        inicio = time.time()
        fin = inicio + config.DURACION_TRABAJO
        os.makedirs(SEG_DIR, exist_ok=True)
        if not config.FB_PAGINAS and not config.MODO_PRUEBA:
            publicar.telegram("Bot Alofoke: no hay páginas configuradas (revisa el secreto FB_PAGINAS). "
                              "Sigo grabando y guardando clips en la cola.", clave="sin_paginas")

        recibidos = cola.recibir_pendientes(SEG_DIR)
        if recibidos:
            print(f"[main] recibí {len(recibidos)} pedazos del turno anterior")

        if config.FUENTE == "drive":
            from clipper.fuente_drive import FuenteDrive
            vistos = self.estado.setdefault("drive_vistos", [])
            grabador = FuenteDrive(SEG_DIR, fin, vistos,
                                   avisar=lambda t: publicar.telegram(t, clave="drive", cada_min=60))
            print("[main] fuente: carpeta de Google Drive")
        else:
            grabador = captura.GrabadorContinuo(
                SEG_DIR, fin, avisar=lambda t: publicar.telegram(t, clave="directo_caido", cada_min=60))
            print("[main] fuente: directo de YouTube")
        grabador.iniciar()
        completos = getattr(grabador, "archivos_completos", False)
        hechos = set()
        tiempo_proceso = 0.0  # cuánto tardó el último pedazo
        while True:
            try:
                archivos = sorted(glob.glob(os.path.join(SEG_DIR, "seg_*.ts")))
                grabando = grabador.vivo()
                # El último pedazo se sigue grabando; solo se procesan los cerrados.
                listos = [a for a in (archivos[:-1] if grabando and not completos else archivos)
                          if a not in hechos]

                if not grabando:
                    # Se acabó el turno: lo que falte, al siguiente turno.
                    if listos:
                        entregados = cola.entregar_pendientes(listos)
                        print(f"[main] entregué {len(entregados)} pedazos al siguiente turno")
                    break

                if len(listos) > 3:  # muy atrasado: salta lo más viejo
                    for a in listos[:-3]:
                        print("[main] me atrasé, salto", os.path.basename(a))
                        hechos.add(a)
                        os.remove(a)
                    listos = listos[-3:]

                # Solo empieza un pedazo si le da tiempo de terminarlo antes del cierre.
                if listos and time.time() + tiempo_proceso * 1.15 < fin:
                    a = listos[0]
                    print("[main] procesando", os.path.basename(a))
                    t0 = time.time()
                    try:
                        self.procesar_segmento(a)
                    except Exception as e:
                        print("[main] falló el pedazo:", e)
                        traceback.print_exc()
                    tiempo_proceso = time.time() - t0
                    print(f"[main] pedazo listo en {tiempo_proceso / 60:.1f} min")
                    hechos.add(a)
                    if os.path.exists(a):
                        os.remove(a)
                    self._guardar_estado()
                else:
                    time.sleep(20)

                self.intentar_publicar()
                if not config.MODO_PRUEBA and aprendizaje.actualizar(self.estado, config.FB_PAGINAS):
                    self._guardar_estado()
            except Exception as e:  # nada debe tumbar el turno
                print("[main] error inesperado:", e)
                traceback.print_exc()
                publicar.telegram(f"Bot Alofoke: error inesperado (sigo trabajando): {str(e)[:300]}",
                                  clave="inesperado", cada_min=60)
                time.sleep(30)

        for pagina in config.FB_PAGINAS:
            self.puede_publicar(pagina)  # limpia publicaciones de más de 24 h
        self._guardar_estado()
        resumen = (f"Turno terminado: {self.producidos} clips nuevos, {len(self.cola)} en cola, "
                   f"{self.total_24h()} publicados en 24 h entre {len(config.FB_PAGINAS)} páginas.")
        print("[main]", resumen)
        publicar.telegram("Bot Alofoke: " + resumen + "\n" + aprendizaje.resumen(self.estado, config.FB_PAGINAS))


if __name__ == "__main__":
    os.makedirs(TRABAJO, exist_ok=True)
    try:
        Bot().correr()
    finally:
        shutil.rmtree(TRABAJO, ignore_errors=True)
